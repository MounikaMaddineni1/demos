package com.cg.movie.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.movie.exception.IExceptionMessages;
import com.cg.movie.exception.MovieException;

public class DBConnect {
	private static Connection connection = null;
	/*****************************************************************
	 *  - Method Name:getConnection() 
	 *  - Input Parameters : 
	 *  - Return Type :DBConnection instance
	 *  - Throws : MovieException 
	 *  - Author : S.Indu Sirisha
	 *  - Creation Date : 22/06/2018
	 *  - Description :  Returns connection object
	 *******************************************************************/
	public static Connection getConnection() throws MovieException {
		if (null == connection) {
			try {
				InitialContext icontext = new InitialContext();
				DataSource dataSource = (DataSource) icontext
						.lookup("java:/jdbc/OracleDS");
				connection = dataSource.getConnection();
			} catch (Exception e) {
				throw new MovieException(IExceptionMessages.ERROR3);
			}
		}
		return connection;
	}
}
