package com.cg.movie.dao;

import java.util.ArrayList;

import com.cg.movie.bean.MovieDetailsBean;
import com.cg.movie.exception.MovieException;

public interface IMovieDAO {

	public ArrayList<MovieDetailsBean> getDetails(String city, String mname)
			throws MovieException;

	public boolean update(String movieid) throws MovieException;

}
