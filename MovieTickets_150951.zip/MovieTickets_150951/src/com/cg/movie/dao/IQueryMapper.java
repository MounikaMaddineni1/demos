package com.cg.movie.dao;

public interface IQueryMapper {
	String QUERY1 = "select movie_id,theatre_name,theatre_location,show_timing,status from movie_master where city=? and movie_name=? and status=?";
	String QUERY2 = "update movie_master set status=? where movie_id=?";
}
