package com.cg.movie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.movie.bean.MovieDetailsBean;
import com.cg.movie.exception.IExceptionMessages;
import com.cg.movie.exception.MovieException;
import com.cg.movie.util.DBConnect;

public class MovieDAOImpl implements IMovieDAO {
	
		/*******************************************************************************************************
		 - Function Name	:	getDetails(String city, String mname)
		 - Input Parameters	:	city,mname
		 - Return Type		:	ArrayList
		 - Throws			:  	MovieException
		 - Author			:	S.Indu Sirisha
		 - Creation Date	:	22/06/2018
		 - Description		:	Getting Details
		 ********************************************************************************************************/
	public ArrayList<MovieDetailsBean> getDetails(String city, String mname)
			throws MovieException {
		ArrayList<MovieDetailsBean> list = new ArrayList<MovieDetailsBean>();
		Connection connection;
		PreparedStatement preparedStatement;
		ResultSet resultSet = null;
		try {
			connection = DBConnect.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY1);
			preparedStatement.setString(1, city);
			preparedStatement.setString(2, mname);
			preparedStatement.setString(3, "Available");
			preparedStatement.executeQuery();
			resultSet = preparedStatement.getResultSet();
			if (!resultSet.isBeforeFirst()) {
				throw new MovieException(IExceptionMessages.ERROR1);
			}
			while (resultSet.next()) {
				MovieDetailsBean bean = new MovieDetailsBean();
				bean.setMovieid(resultSet.getString(1));
				bean.setTname(resultSet.getString(2));
				bean.setTlocation(resultSet.getString(3));
				bean.setShowtime(resultSet.getString(4));
				bean.setStatus(resultSet.getString(5));
				list.add(bean);
			}
		} catch (MovieException | SQLException e) {
			// TODO Auto-generated catch block
			throw new MovieException(IExceptionMessages.ERROR1);
		}

		return list;
	}
		/*******************************************************************************************************
		 - Function Name	:	update(String movieid)
		 - Input Parameters	:	movieid
		 - Return Type		:	boolean
		 - Throws			:  	MovieException
		 - Author			:	S.Indu Sirisha
		 - Creation Date	:	22/06/2018
		 - Description		:	Updating status
		 ********************************************************************************************************/
	public boolean update(String movieid) throws MovieException {
		boolean result = false;
		Connection connection;
		PreparedStatement preparedStatement;
		try {
			connection = DBConnect.getConnection();
			preparedStatement = connection
					.prepareStatement(IQueryMapper.QUERY2);
			preparedStatement.setString(1, "Not Available");
			preparedStatement.setString(2, movieid);
			preparedStatement.executeUpdate();
			result = true;
		} catch (MovieException | SQLException e) {
			// TODO Auto-generated catch block
			throw new MovieException(IExceptionMessages.ERROR2);
		}
		return result;
	}
}
