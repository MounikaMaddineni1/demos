package com.cg.movie.service;

import java.util.ArrayList;

import com.cg.movie.bean.MovieDetailsBean;
import com.cg.movie.exception.MovieException;

public interface IMovieService {
	public ArrayList<MovieDetailsBean> getDetails(String city, String mname)
			throws MovieException;

	public boolean update(String movieid) throws MovieException;
}
