package com.cg.movie.service;

import java.util.ArrayList;

import com.cg.movie.bean.MovieDetailsBean;
import com.cg.movie.dao.IMovieDAO;
import com.cg.movie.dao.MovieDAOImpl;
import com.cg.movie.exception.MovieException;

public class MovieServiceImpl implements IMovieService {
	IMovieDAO dao = new MovieDAOImpl();
	/*******************************************************************************************************
	 - Function Name	:	getDetails(String city, String mname)
	 - Input Parameters	:	city,mname
	 - Return Type		:	ArrayList
	 - Throws			:  	MovieException
	 - Author			:	S.Indu Sirisha
	 - Creation Date	:	22/06/2018
	 - Description		:	Getting Details
	 ********************************************************************************************************/
	public ArrayList<MovieDetailsBean> getDetails(String city, String mname)
			throws MovieException {
		return dao.getDetails(city, mname);
	}
	/*******************************************************************************************************
	 - Function Name	:	update(String movieid)
	 - Input Parameters	:	movieid
	 - Return Type		:	boolean
	 - Throws			:  	MovieException
	 - Author			:	S.Indu Sirisha
	 - Creation Date	:	22/06/2018
	 - Description		:	Updating status
	 ********************************************************************************************************/
	public boolean update(String movieid) throws MovieException {
		return dao.update(movieid);
	}
}
