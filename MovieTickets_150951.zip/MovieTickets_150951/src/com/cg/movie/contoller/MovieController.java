package com.cg.movie.contoller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.movie.bean.MovieDetailsBean;
import com.cg.movie.exception.MovieException;
import com.cg.movie.service.IMovieService;
import com.cg.movie.service.MovieServiceImpl;

@WebServlet("/MovieController")
public class MovieController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		IMovieService movieService = new MovieServiceImpl();
		boolean result = false;
		HttpSession httpSession = request.getSession();
		try {
			if (request.getParameter("submit").equalsIgnoreCase("Proceed")) {
				String city = request.getParameter("city");
				String mname = request.getParameter("mname");
				httpSession.setAttribute("city", city);
				httpSession.setAttribute("mname", mname);
				ArrayList<MovieDetailsBean> list = new ArrayList<MovieDetailsBean>();
				list = movieService.getDetails(city, mname);//calling getDetails() method with parameters city and movie name
				if (!list.isEmpty()) {
					httpSession.setAttribute("list", list);
					getServletContext().getRequestDispatcher(
							"/views/MovieDetails.jsp").include(request, response);
				} else {
					getServletContext().getRequestDispatcher("/views/Failure.jsp")
							.include(request, response);
				}
				
			} else {
				String movieid = request.getParameter("movieid");
				httpSession.setAttribute("movieid", movieid);//calling update() method with parameters movie id
				result = movieService.update(movieid);
				if (result) {
					getServletContext().getRequestDispatcher("/views/Success.jsp")
							.include(request, response);
				} else {
					getServletContext().getRequestDispatcher("/views/Failure.jsp")
							.include(request, response);
				}
			}
		} catch (MovieException e) {
			// TODO Auto-generated catch block
			request.setAttribute("ErrorMessage", e.getMessage());
			getServletContext().getRequestDispatcher("/views/Failure.jsp").include(
					request, response);
		}

	}

}
