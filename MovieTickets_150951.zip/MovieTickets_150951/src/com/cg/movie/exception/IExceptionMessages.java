package com.cg.movie.exception;

public interface IExceptionMessages {
	String ERROR1 = "Retrieving Details from MovieMaster failed.";
	String ERROR2 = "Updating Details in MovieMaster failed.";
	String ERROR3 = "Connection to the DataSource could not be established.";
}
