package com.cg.service;

import java.util.ArrayList;

import com.cg.client.Timesheet;

public interface ITimeSheetService {

	public Timesheet add(Timesheet bean);

	public ArrayList getPlan(String empId);

}
