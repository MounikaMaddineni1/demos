package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.Timesheet;
import com.cg.dao.ITimeSheetDAO;

@Service("service")
public class TimeSheetServiceImpl implements ITimeSheetService {

	@Autowired
	ITimeSheetDAO dao;

	@Override
	public Timesheet add(Timesheet bean) {

		return dao.add(bean);
	}

	@Override
	public ArrayList getPlan(String empId) {

		return dao.getPlan(empId);
	}

}
