package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.client.Timesheet;

@Repository("dao")
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/***********************************************************
	 * Method Name: add
	 * Return type:TimeSheet Bean
	 * Parameters:Object of type TimeSheetBean
	 * Package Name: com.cg.dao
	 * @author M.Mounika
	 ***********************************************************/

	@Override
	public Timesheet add(Timesheet bean) {

		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}
	
	/***********************************************************
	 * Method Name: getPlan 
	 * Return type:	ArrayList
	 * Parameters:	empId String
	 * Package Name: com.cg.dao
	 * @author M.Mounika
	 ***********************************************************/


	@Override
	public ArrayList getPlan(String empId) {
		
		Query query = entityManager
				.createQuery("SELECT t FROM Timesheet t where t.empId=:empId");
		query.setParameter("empId", empId);
		ArrayList list = (ArrayList) query.getResultList();
		return list;
	}

}
