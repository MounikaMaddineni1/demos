package com.cg.dao;

import java.util.ArrayList;

import com.cg.client.Timesheet;

public interface ITimeSheetDAO {

	public Timesheet add(Timesheet bean);

	public ArrayList getPlan(String empId);

}
