package com.cg.client;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TimeSheet")
public class Timesheet {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Timesheet_id")
	private int timeSheetId;

	@Column(name = "emp_id")
	@NotEmpty(message = "Employee id should not be Empty ,please enter value")
	@Pattern(regexp = "[A-Z]{3}[0-9]{5}$", message = "employee id should be alpha numeric")
	private String empId;

	@Column(name = "Timesheet_Date")
	@NotEmpty(message = "Date Not Found")
	private String date;

	@Column(name = "hour1")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr1;

	@Column(name = "hour2")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr2;

	@Column(name = "hour3")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr3;

	@Column(name = "hour4")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr4;

	@Column(name = "hour5")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr5;

	@Column(name = "hour6")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr6;

	@Column(name = "hour7")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr7;

	@Column(name = "hour8")
	@NotEmpty(message = "Option should not be Empty ,please enter value")
	private String hr8;

	public int getTimeSheetId() {
		return timeSheetId;
	}

	public void setTimeSheetId(int timeSheetId) {
		this.timeSheetId = timeSheetId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getHr1() {
		return hr1;
	}

	public void setHr1(String hr1) {
		this.hr1 = hr1;
	}

	public String getHr2() {
		return hr2;
	}

	public void setHr2(String hr2) {
		this.hr2 = hr2;
	}

	public String getHr3() {
		return hr3;
	}

	public void setHr3(String hr3) {
		this.hr3 = hr3;
	}

	public String getHr4() {
		return hr4;
	}

	public void setHr4(String hr4) {
		this.hr4 = hr4;
	}

	public String getHr5() {
		return hr5;
	}

	public void setHr5(String hr5) {
		this.hr5 = hr5;
	}

	public String getHr6() {
		return hr6;
	}

	public void setHr6(String hr6) {
		this.hr6 = hr6;
	}

	public String getHr7() {
		return hr7;
	}

	public void setHr7(String hr7) {
		this.hr7 = hr7;
	}

	public String getHr8() {
		return hr8;
	}

	public void setHr8(String hr8) {
		this.hr8 = hr8;
	}

	@Override
	public String toString() {
		return "Timesheet [timeSheetId=" + timeSheetId + ", empId=" + empId
				+ ", date=" + date + ", hr1=" + hr1 + ", hr2=" + hr2 + ", hr3="
				+ hr3 + ", hr4=" + hr4 + ", hr5=" + hr5 + ", hr6=" + hr6
				+ ", hr7=" + hr7 + ", hr8=" + hr8 + "]";
	}

}
