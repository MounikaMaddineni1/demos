package com.cg.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.client.Timesheet;
import com.cg.service.ITimeSheetService;

@Controller
public class TimeSheetController {
	@Autowired
	ITimeSheetService service;


	/***********************************************************
	 * Method Name: homepage
	 * Return type:String
	 * Parameters :No
	 * Description:This method returns the name of the view that is to be displayed on the browser.
	 * @author M.Mounika
	 ***********************************************************/
	
	@RequestMapping("index")
	public String homepage() {
		String view = null;
		view = "HomePage";
		return view;
	}
	
	/***********************************************************
	 * Method Name: addTimeSheet(Model model) 
	 * Return type:String
	 * Parameters :Object of type Model 
	 * Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author M.Mounika
	 ***********************************************************/
	
	@RequestMapping("addtimesheet")
	public String addTimeSheet(Model model) {
		Timesheet bean = new Timesheet();
		LocalDate localDate = LocalDate.now();
		Date date = java.sql.Date.valueOf(localDate);
		model.addAttribute("date", date);
		model.addAttribute("bean", bean);
		model.addAttribute("selhour", new String[] { "DATA_ENTRY",
				"ACCOUNTS_TALLY", "LEDGER_POSTINGS", "BALANCE_SHEET",
				"RETURNS_FILING" });

		return "Add_Timesheet";
	}
	
	/***********************************************************
	 * Method Name: insertSheet
	 * Return type: String 
	 * Parameters:Object of type Model,Binding Result,Question 
	 * Description:This validates the Object
	 * fields and if success calls the service layer method to add the TimeSheet
	 * to the database.
	 * 
	 * @author M.Mounika
	 ***********************************************************/

	@RequestMapping(value = "insert", method = RequestMethod.POST)
	public String insertSheet(Model model,
			@ModelAttribute("bean") @Valid Timesheet bean, BindingResult result) {
		String string = null;
		String view = null;
		ArrayList<String> arraylist = new ArrayList<String>();
		arraylist.add(bean.getEmpId());
		arraylist.add(bean.getDate());
		arraylist.add(bean.getHr1());
		arraylist.add(bean.getHr2());
		arraylist.add(bean.getHr3());
		arraylist.add(bean.getHr4());
		arraylist.add(bean.getHr5());
		arraylist.add(bean.getHr6());
		arraylist.add(bean.getHr7());
		arraylist.add(bean.getHr8());

		if (result.hasErrors()) {
			view = "Add_Timesheet";
		} else {
			Timesheet obj = service.add(bean);
			model.addAttribute("bean", obj);
			model.addAttribute("id", bean.getTimeSheetId());
			view = "Success";

		}
		System.out.println(view);
		return view;
	}
	
	/***********************************************************
	 * Method Name: viewByPlanId(Model model) 
	 * Return type:String
	 * Parameters :Object of type Model 
	 * Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author M.Mounika
	 ***********************************************************/

	@RequestMapping("Viewbyid")
	public String viewByPlanId(Model model) {
		Timesheet bean = new Timesheet();
		model.addAttribute("bean", bean);

		return "ViewById";
	}
	
	/***********************************************************
	 * Method Name: getSinglePlan
	 * Return type: String 
	 * Parameters:Object of type Model,Binding Result,Question 
	 * Description:This validates the Object
	 * fields and if success calls the service layer method to display data
	 * from the database.
	 * 
	 * @author M.Mounika
	 ***********************************************************/

	@RequestMapping(value = "singleplan", method = RequestMethod.POST)
	public String getSinglePlan(Model model,
			@ModelAttribute("bean") @Valid Timesheet bean, BindingResult result) {
		ArrayList arr = service.getPlan(bean.getEmpId());
		System.out.println(arr);
		model.addAttribute("singlerow", arr);
		if (arr.isEmpty()) {
			model.addAttribute("singlerows", "No time sheets recorded!");
		}
		return "ViewById";
	}

}
