package com.cg.timesheet.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.timesheet.bean.TimeSheet;
import com.cg.timesheet.service.ITimeSheetService;

@Controller
public class TimeSheetController {
	@Autowired
	ITimeSheetService service;

	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView();
		view.setViewName("HomePage");
		return view;
	}

	@RequestMapping("entry")
	public ModelAndView addPage() {
		ModelAndView view = new ModelAndView("TimeSheetEntry", "bean",
				new TimeSheet());
		LocalDate date = LocalDate.now();
		view.addObject("hourList", new String[] { "DATA ENTRY",
				"ACCOUNTS_TALLY", "LEDGER_POSTINGS", "BALANCE_SHEET",
				"RETURNS_FILING" });
		view.addObject("date", date);
		return view;
	}

	@RequestMapping("insert")
	public ModelAndView addDetails(
			@Valid @ModelAttribute("bean") TimeSheet bean, BindingResult result) {
		ModelAndView view = new ModelAndView();
		if (result.hasErrors()) {
			view.setViewName("TimeSheetEntry");
			String msg = "Please go to home page and ENTER TIME SHEET AGAIN!";
			view.addObject("msg", msg);
		} else {
			boolean res = service.addDetails(bean);
			view.addObject("id", bean.getTimesheetId());
			// view.setViewName("HomePage");
			if (res) {
				view.setViewName("Success");
			} else {
				view.setViewName("HomePage");
			}
		}
		return view;

	}

	@RequestMapping("list")
	public ModelAndView getDetails() {
		ModelAndView view = new ModelAndView("TimeSheetList", "bean",
				new TimeSheet());
		return view;
	}

	@RequestMapping("retrieve")
	public ModelAndView retrieveDetails(@ModelAttribute("bean") TimeSheet bean) {
		ArrayList<TimeSheet> list = service.getDetails(bean.getEmpId());
		ModelAndView view = new ModelAndView("TimeSheetList", "bean",
				new TimeSheet());
		if (!list.isEmpty())
			view.addObject("list", list);
		else {
			String msg = "No time sheets recorded!";
			view.addObject("msg", msg);
		}
		return view;
	}

	public TimeSheetController() {
		// TODO Auto-generated constructor stub
	}

}
