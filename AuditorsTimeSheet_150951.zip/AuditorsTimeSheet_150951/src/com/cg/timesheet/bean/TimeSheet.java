package com.cg.timesheet.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.annotations.NamedQuery;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "TimeSheet")
@NamedQuery(name = "getalldetails", query = "select t from TimeSheet t where t.empId=:id")
public class TimeSheet {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "timesheet_id")
	private Integer timesheetId;
	@Column(name = "emp_id")
	@NotEmpty(message = "This field is mandatory")
	@Size(max = 8, message = "Id should not be more than 8 characters")
	@Pattern(regexp = "[A-Z]{3}[0-9]{5}", message = "Id should have first three chars upper case and the other five are digits from 0-9")
	private String empId;
	@Column(name = "timesheet_date")
	private Date timesheetDate;
	@Column(name = "hour1")
	private String hour1;
	@Column(name = "hour2")
	private String hour2;
	@Column(name = "hour3")
	private String hour3;
	@Column(name = "hour4")
	private String hour4;
	@Column(name = "hour5")
	private String hour5;
	@Column(name = "hour6")
	private String hour6;
	@Column(name = "hour7")
	private String hour7;

	@Override
	public String toString() {
		return "TimeSheet [timesheetId=" + timesheetId + ", empId=" + empId
				+ ", timesheetDate=" + timesheetDate + ", hour1=" + hour1
				+ ", hour2=" + hour2 + ", hour3=" + hour3 + ", hour4=" + hour4
				+ ", hour5=" + hour5 + ", hour6=" + hour6 + ", hour7=" + hour7
				+ ", hour8=" + hour8 + "]";
	}

	public Integer getTimesheetId() {
		return timesheetId;
	}

	public void setTimesheetId(Integer timesheetId) {
		this.timesheetId = timesheetId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public Date getTimesheetDate() {
		return timesheetDate;
	}

	public void setTimesheetDate(Date timesheetDate) {
		this.timesheetDate = timesheetDate;
	}

	public String getHour1() {
		return hour1;
	}

	public void setHour1(String hour1) {
		this.hour1 = hour1;
	}

	public String getHour2() {
		return hour2;
	}

	public void setHour2(String hour2) {
		this.hour2 = hour2;
	}

	public String getHour3() {
		return hour3;
	}

	public void setHour3(String hour3) {
		this.hour3 = hour3;
	}

	public String getHour4() {
		return hour4;
	}

	public void setHour4(String hour4) {
		this.hour4 = hour4;
	}

	public String getHour5() {
		return hour5;
	}

	public void setHour5(String hour5) {
		this.hour5 = hour5;
	}

	public String getHour6() {
		return hour6;
	}

	public void setHour6(String hour6) {
		this.hour6 = hour6;
	}

	public String getHour7() {
		return hour7;
	}

	public void setHour7(String hour7) {
		this.hour7 = hour7;
	}

	public String getHour8() {
		return hour8;
	}

	public void setHour8(String hour8) {
		this.hour8 = hour8;
	}

	@Column(name = "hour8")
	private String hour8;

	public TimeSheet() {
		// TODO Auto-generated constructor stub
	}

}
