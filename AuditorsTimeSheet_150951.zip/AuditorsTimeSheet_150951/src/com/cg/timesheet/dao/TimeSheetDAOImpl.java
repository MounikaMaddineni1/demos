package com.cg.timesheet.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.timesheet.bean.TimeSheet;

@Repository
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {
	@PersistenceContext
	EntityManager entityManager;

	public TimeSheetDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	/*******************************************************************************************************
	 * - Function Name : addDetails(TimeSheet bean) - Input Parameters : bean -
	 * Return Type : boolean - Author : S.Indu Sirisha - Creation Date :
	 * 10/07/2018 - Description : Inserting values
	 ********************************************************************************************************/
	@Override
	public boolean addDetails(TimeSheet bean) {
		// TODO Auto-generated method stub
		boolean result = false;
		entityManager.persist(bean);
		entityManager.flush();
		result = true;
		return result;
	}

	/*******************************************************************************************************
	 * - Function Name : getDetails(String empId) - Input Parameters : empId -
	 * Return Type : ArrayList - Author : S.Indu Sirisha - Creation Date :
	 * 10/07/2018 - Description : Retrieving values based on employee id
	 ********************************************************************************************************/

	@Override
	public ArrayList<TimeSheet> getDetails(String empId) {
		// TODO Auto-generated method stub
		Query query = entityManager.createNamedQuery("getalldetails");
		query.setParameter("id", empId);
		ArrayList<TimeSheet> list = (ArrayList<TimeSheet>) query
				.getResultList();
		return list;
	}

}
