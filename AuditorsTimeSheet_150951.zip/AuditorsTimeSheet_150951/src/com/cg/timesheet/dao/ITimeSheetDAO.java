package com.cg.timesheet.dao;

import java.util.ArrayList;

import com.cg.timesheet.bean.TimeSheet;

public interface ITimeSheetDAO {

	public boolean addDetails(TimeSheet bean);

	public ArrayList<TimeSheet> getDetails(String empId);

}
