package com.cg.timesheet.service;

import java.util.ArrayList;

import com.cg.timesheet.bean.TimeSheet;

public interface ITimeSheetService {

	public boolean addDetails(TimeSheet bean);

	public ArrayList<TimeSheet> getDetails(String empId);

}
