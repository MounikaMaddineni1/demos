package com.cg.timesheet.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.timesheet.bean.TimeSheet;
import com.cg.timesheet.dao.ITimeSheetDAO;

@Service
public class TimeSheetServiceImpl implements ITimeSheetService {
	@Autowired
	ITimeSheetDAO dao;

	public TimeSheetServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	/*******************************************************************************************************
	 * - Function Name : addDetails(TimeSheet bean) - Input Parameters : bean -
	 * Return Type : boolean - Author : S.Indu Sirisha - Creation Date :
	 * 10/07/2018 - Description : Inserting values
	 ********************************************************************************************************/
	@Override
	public boolean addDetails(TimeSheet bean) {
		// TODO Auto-generated method stub
		return dao.addDetails(bean);
	}

	/*******************************************************************************************************
	 * - Function Name : getDetails(String empId) - Input Parameters : empId -
	 * Return Type : ArrayList - Author : S.Indu Sirisha - Creation Date :
	 * 10/07/2018 - Description : Retrieving values based on employee id
	 ********************************************************************************************************/
	@Override
	public ArrayList<TimeSheet> getDetails(String empId) {
		// TODO Auto-generated method stub
		return dao.getDetails(empId);
	}

}
